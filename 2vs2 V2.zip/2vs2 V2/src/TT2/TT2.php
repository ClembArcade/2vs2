<?php

namespace TT2;

use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;
use pocketmine\utils\Config;
use pocketmine\level\sound\ZombieInfectSound;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\AngryRunnerParticle;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\level\Position;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\Player;
use pocketmine\tile\Sign;
use pocketmine\level\Level;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use TT2\ResetMap;
use pocketmine\level\sound\PopSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\block\Air;
use pocketmine\item\Item;
use pocketmine\event\entity\EntityLevelChangeEvent;

class TT2 extends PluginBase implements Listener {

    public $prefix = TE::GRAY . "[" . TE::WHITE. TE::GOLD . "§f2v§6s2§r" . TE::GRAY . "]";
	public $mode = 0;
	public $arenas = array();
	public $currentLevel = "";
    public $op = array();

	
	public function onEnable()
	{
		  $this->getLogger()->info(TE::GRAY . "2vs2 Enabled");
                  
                $this->getServer()->getPluginManager()->registerEvents($this ,$this);
         
		@mkdir($this->getDataFolder());
		$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
		if($config->get("arenas")!=null)
		{
			$this->arenas = $config->get("arenas");
		}
		foreach($this->arenas as $lev)
		{
			$this->getServer()->loadLevel($lev);
		}
		
		$config->save();
                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                $slots->save();
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new GameSender($this), 20);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new RefreshSigns($this), 20);
	}
        
        public function onDisable() {
            $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
            $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
            if($config->get("arenas")!=null)
            {
                    $this->arenas = $config->get("arenas");
            }
            foreach($this->arenas as $arena)
            {
                $slots->set("slot1".$arena, 0);
                $slots->set("slot2".$arena, 0);
                $slots->set("slot3".$arena, 0);
                $slots->set("slot4".$arena, 0);     
                $config->set($arena . "inicio", 0);
                $slots->save();
                $this->reload($arena);
            }
        }
        
        public function reload($lev)
        {
                if ($this->getServer()->isLevelLoaded($lev))
                {
                        $this->getServer()->unloadLevel($this->getServer()->getLevelByName($lev));
                }
                $zip = new \ZipArchive;
                $zip->open($this->getDataFolder() . 'arenas/' . $lev . '.zip');
                $zip->extractTo($this->getServer()->getDataPath() . 'worlds');
                $zip->close();
                unset($zip);
                return true;
        }
	
	public function onDeath(PlayerDeathEvent $event){
        $jugador = $event->getEntity();
        $mapa = $jugador->getLevel()->getFolderName();
        if(in_array($mapa,$this->arenas))
		{
                $event->setDeathMessage("");
                if($event->getEntity()->getLastDamageCause() instanceof EntityDamageByEntityEvent)
                {
                $asassin = $event->getEntity()->getLastDamageCause()->getDamager();
                if($asassin instanceof Player){
                foreach($jugador->getLevel()->getPlayers() as $pl){
 
            
              
				$pl->sendMessage($jugador->getNameTag() . TE::GOLD . " §ofue Asesinado por§7 " . $asassin->getNameTag());
				
				$jugador->addTitle("Asesinado");
				
				
						
			}
                }
                }
                else
                {
                foreach($jugador->getLevel()->getPlayers() as $pl){
                $pl->sendMessage($jugador->getNameTag() . TE::DARK_RED . " §oJugador muerto");
                }
                }
                
                }
        }
        
        public function chang($pl) {
            $level = $pl->getLevel()->getFolderName();
            if(in_array($level,$this->arenas))
            {
                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                for ($i = 1; $i <= 4; $i++) {
                    if($slots->get("slot".$i.$level)==$pl->getName())
                    {
                        $slots->set("slot".$i.$level, 0);
                    }
                }
                $slots->save();
            }
        }
	
        public function enCambioMundo(EntityLevelChangeEvent $event)
        {
            $pl = $event->getEntity();
            if($pl instanceof Player)
            {
                $lev = $event->getOrigin();
                if($lev instanceof Level && in_array($lev->getFolderName(),$this->arenas))
		{
                $level = $lev->getFolderName();
                $pl->removeAllEffects();
                $pl->getInventory()->clearAll();
                $pl->setNameTag($pl->getName());
          
                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                for ($i = 1; $i <= 4; $i++) {
                    if($slots->get("slot".$i.$level)==$pl->getName())
                    {
                        $slots->set("slot".$i.$level, 0);
                    }
                }
                $slots->save();
                }
            }
        }

        public function onLog(PlayerLoginEvent $event)
	{
            $player = $event->getPlayer();
            if(in_array($player->getLevel()->getFolderName(),$this->arenas))
            {
            $player->getInventory()->clearAll();
            $spawn = $this->getServer()->getDefaultLevel()->getSafeSpawn();
            $this->getServer()->getDefaultLevel()->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
            $player->teleport($spawn,0,0);
            }
	}
        
        public function onQuit(PlayerQuitEvent $event)
        {
            $pl = $event->getPlayer();
            $level = $pl->getLevel()->getFolderName();
            if(in_array($level,$this->arenas))
            {
            $pl->getInventory()->clearAll();
            
            $pl->setNameTag($pl->getName());
            $this->chang($pl);
            }
        }
          
	
	public function onBlockBr(BlockBreakEvent $event)
	{
            $player = $event->getPlayer();
            $level = $player->getLevel()->getFolderName();
            if(in_array($level,$this->arenas))
            {
                $event->setCancelled();
            }
	}
        
        public function onBlockPl(BlockPlaceEvent $event)
	{
            $player = $event->getPlayer();
            $level = $player->getLevel()->getFolderName();
            if(in_array($level,$this->arenas))
            {
                $event->setCancelled();
            }
	}
	
       
        public function onDam(EntityDamageEvent $event) {
            $player = $event->getEntity();
            $level = $player->getLevel()->getFolderName();
            if(in_array($level,$this->arenas))
            {
            if ($event instanceof EntityDamageByEntityEvent) {
                if ($player instanceof Player && $event->getDamager() instanceof Player) {
                $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                if($config->get($level . "PlayTime") != null)
                {
                        if($config->get($level . "PlayTime") > 699)
                        {
                                $event->setCancelled();
                         
                        }
                        elseif ((strpos($player->getNameTag(), "§7[§bAzul§7]§b") !== false) && (strpos($event->getDamager()->getNameTag(), "§7[§bAzul§7]§b") !== false)) {
                        $event->setCancelled();
                          
                        }
                    
                             elseif ((strpos($player->getNameTag(), "§7[§4Rojo§7]§b") !== false) && (strpos($event->getDamager()->getNameTag(), "§7[§4Rojo§7]§b") !== false)) {
                        $event->setCancelled();
                   
                        }
                        else
                        {
                        	       
                        $event->setKnockBack(0.2);
                        }
                }
                }
                }
            }
        }
	
	public function onCommand(CommandSender $player, Command $cmd, $label, array $args) {
        switch($cmd->getName()){
			case "2vs2":
                            if($player->isOp())
                            {
                                if(!empty($args[0]))
                                {
                                    if($args[0]=="create")
                                    {
                                        if(!empty($args[1]))
                                        {
                                            if(file_exists($this->getServer()->getDataPath() . "/worlds/" . $args[1]))
                                            {
                                                $this->getServer()->loadLevel($args[1]);
                                                $this->getServer()->getLevelByName($args[1])->loadChunk($this->getServer()->getLevelByName($args[1])->getSafeSpawn()->getFloorX(), $this->getServer()->getLevelByName($args[1])->getSafeSpawn()->getFloorZ());
                                                array_push($this->arenas,$args[1]);
                                                $this->currentLevel = $args[1];
                                                $this->mode = 1;
                                                $player->addTitle("§bGalaxy§c Config");              
                                                $player->sendMessage($this->prefix . "§6#1 §fToca spawn de team: azul y rojo");
                                                 $player->sendMessage($this->prefix . "§6#2 §fToca lobby de jugadores");
                                                    $player->sendTip("§fGalaxy §dConfig...");               
                                                $player->setGamemode(1);
                                                array_push($this->op, $player->getName());
                                                $player->teleport($this->getServer()->getLevelByName($args[1])->getSafeSpawn(),0,0);
                                                $name = $args[1];
                                                $this->zipper($player, $name);
                                            }
                                            else
                                            {
                                                    $player->sendMessage($this->prefix . "Mundo no encontrado");
                                                    $player->addTitle("§bGalaxy §cError");
                                            }
                                        }
                                        else
                                        {
                                                $player->sendMessage($this->prefix . "Comando mal puesto");
                                                    $player->addTitle("§bGalaxy §cError");              
                                        }
                                    }
                                    else
                                    {
                                            $player->sendMessage($this->prefix . "Codigo no Existente.");
                                                    $player->addTitle("§bGalaxy §cError");          
                                    }
                                }
                                else
                                {
                                 $player->sendMessage($this->prefix . "§f>>§f2v§bs2§e Comandos!§b<<");
                                 $player->sendMessage($this->prefix . "§f>§b/2vs2 create [world]:Crear game!");
                                 $player->sendMessage($this->prefix . "§f>§b/arena join Unirse batalla!"); 
                                 $player->sendMessage($this->prefix . "§f>§b/vstart Comenzar la Batalla VS");
                                }
                            }
			return true;

                        case "vsstart":
                            if($player->isOp())
				{
                                if(!empty($args[0]))
					{
                                        $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                                        if($config->get($args[0] . "StartTime") != null)
                                        {
                                        $config->set($args[0] . "StartTime", 4);
                                        $config->save();
                                        $player->sendMessage($this->prefix . "§oEmpezando en 4...");
                                        }
                                        }
                                        else
                                        {
                                            $level = $player->getLevel()->getFolderName();
                                            $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                                            if($config->get($level . "StartTime") != null)
                                            {
                                            $config->set($level . "StartTime", 4);
                                            $config->save();
            
                                            $player->sendMessage("§fStarting");         $player->sendMessage($this->prefix . "§oEmpezando en 4...");
                                            }
                                        }
                                }
                                return true;
	}
        }
	
	public function onInteract(PlayerInteractEvent $event)
	{
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$tile = $player->getLevel()->getTile($block);
		
		if($tile instanceof Sign) 
		{
			if(($this->mode==26)&&(in_array($player->getName(), $this->op)))
			{
				$tile->setText(TE::AQUA . "[Unirse]",TE::WHITE  . "0 / §f4","§b" . $this->currentLevel,$this->prefix);
				$this->refreshArenas();
				$this->currentLevel = "";
				$this->mode = 0;
				$player->sendMessage($this->prefix . "Arena Registrada :)!");
                                array_shift($this->op);
			}
			else
			{
				$text = $tile->getText();
                             
				if($text[3] == $this->prefix)
				{
                                        if($text[0]==TE::GRAY . "§7[§bEscaso§7]")
                                        {
                                            $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                                            $namemap = str_replace("§b", "", $text[2]);
                                            $level = $this->getServer()->getLevelByName($namemap);
                                         
                                            $player->setGamemode(0);
                                            $player->getInventory()->clearAll();
                                                $player->removeAllEffects();
                                                $player->setMaxHealth(20);
                                                $player->setHealth(20);
                                                $player->setFood(20);
                                                $spawn = new Position($thespawn[0]+0.5,$thespawn[1],$thespawn[2]+0.5,$level);
						$level->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
						$player->teleport($spawn,0,0);
                                                if(strpos($player->getNameTag(), "§7[§4Red§7]§b") !== false)
                                                {
                                          
                                                }
                                                
                                                foreach($level->getPlayers() as $playersinarena)
                                                {
                                                $playersinarena->sendMessage($player->getNameTag() . " §7se unió al juego");
                                                }
                                        }
					elseif($text[0]==TE::AQUA . "[Unirse]")
					{
						$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                                                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                                                $namemap = str_replace("§b", "", $text[2]);
						$level = $this->getServer()->getLevelByName($namemap);
                                                if(strpos($player->getNameTag(), "§7[§4Rojo§7]§b") !== false)
                                                {
                                                    
                                                    if($slots->get("slot2".$namemap)==null)
                                                    {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot2".$namemap, $player->getName());
                                                    }
                                                   
                                                    
                                                    else
                                                    {
                                                    
                                                        goto sinequipo;
                                                    }
                                                }
                                                elseif(strpos($player->getNameTag(), "§7[§bTurn§7]§b") !== false)
                                                {
                                                    
                                                    $thespawn = $config->get($namemap . "Spawn3");
                                                }
                                                elseif($slots->get("slot1".$namemap)==null)
                                                {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot1".$namemap, $player->getName());
                                                        $player->setNameTag("§7[§bAzul§7]§b".TE::GRAY.$player->getName());
                                                        
                                                      
                                                }
                                                elseif($slots->get("slot2".$namemap)==null)
                                                {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot2".$namemap, $player->getName());
                                                        $player->setNameTag("§7[§4Rojo§7]§b".TE::GRAY.$player->getName());
                                                   
                                                        
                                                       
                                                }
                                                elseif($slots->get("slot3".$namemap)==null)
                                                {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot3".$namemap, $player->getName());
                                                   $player->setNameTag("§7[§bAzul§7]§b".TE::GRAY.$player->getName());
                                                }
                                                elseif($slots->get("slot4".$namemap)==null)
                                                {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot4".$namemap, $player->getName());
                                                        $player->setNameTag("§7[§4Rojo§7]§b".TE::GRAY.$player->getName());

                                                }
                                             
                                                
                                           
                                                else
                                                {
                                                    SinSlotsSuficientes:
                                                    $player->sendMessage($this->prefix.TE::RED."§oNo hay lugares disponibles.");
                                                    goto sinequipo;
                                                }
                                                $slots->save();
                                                $player->setGamemode(0);
						$player->getInventory()->clearAll();
                                                $player->removeAllEffects();
                                                $player->setMaxHealth(20);
                                                $player->setHealth(20);
                                                $player->setFood(20);
                                                $spawn = new Position($thespawn[0]+0.5,$thespawn[1],$thespawn[2]+0.5,$level);
						$level->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
						$player->teleport($spawn,0,0);
                                               if(strpos($player->getNameTag(), "§o§c[SnowRed]") !== false)
                                                {
                   
                                          
                   }
                                                foreach($level->getPlayers() as $playersinarena)
                                                {
                                                $playersinarena->sendMessage($player->getNameTag() .TE::GRAY. " se unió al juego");
                                                }
                                                sinequipo:
					}
					else
					{
						$player->sendMessage($this->prefix . " el juego ha iniciado");
					}
				}
			}
		}
		elseif(in_array($player->getName(), $this->op)&&$this->mode<=2)
		{
			$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
			$config->set($this->currentLevel . "Spawn" . $this->mode, array($block->getX(),$block->getY()+1,$block->getZ()));
			$player->sendMessage($this->prefix . "Spawn registrado!");
			$this->mode++;
			$config->save();
		}
		elseif(in_array($player->getName(), $this->op)&&$this->mode==3)
		{
			$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
			$config->set($this->currentLevel . "Spawn" . $this->mode, array($block->getX(),$block->getY()+1,$block->getZ()));
			$player->sendMessage($this->prefix . "§olobby Registrado");
			$config->set("arenas",$this->arenas);
                        $config->set($this->currentLevel . "inicio", 0);
			$player->sendMessage($this->prefix . "Toca un cartel para registrar Arena!");
			$spawn = $this->getServer()->getDefaultLevel()->getSafeSpawn();
			$this->getServer()->getDefaultLevel()->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
			$player->teleport($spawn,0,0);
			$config->save();
			$this->mode=26;
		}
	}
	
	public function refreshArenas()
	{
		$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
		$config->set("arenas",$this->arenas);
		foreach($this->arenas as $arena)
		{
			$config->set($arena . "PlayTime", 700);
			$config->set($arena . "StartTime", 10);
		}
		$config->save();
	}
        
        public function zipper($player, $name)
        {
        $path = realpath($player->getServer()->getDataPath() . 'worlds/' . $name);
				$zip = new \ZipArchive;
				@mkdir($this->getDataFolder() . 'arenas/', 0755);
				$zip->open($this->getDataFolder() . 'arenas/' . $name . '.zip', $zip::CREATE | $zip::OVERWRITE);
				$files = new \RecursiveIteratorIterator(
					new \RecursiveDirectoryIterator($path),
					\RecursiveIteratorIterator::LEAVES_ONLY
				);
                                foreach ($files as $datos) {
					if (!$datos->isDir()) {
						$relativePath = $name . '/' . substr($datos, strlen($path) + 1);
						$zip->addFile($datos, $relativePath);
					}
				}
				$zip->close();
				$player->getServer()->loadLevel($name);
				unset($zip, $path, $files);
        }
}

class RefreshSigns extends PluginTask {
    public $prefix = TE::GRAY . "[" . TE::WHITE. TE::GOLD . "§f2v§6s2§r" . TE::GRAY . "]";
	public function __construct($plugin)
	{
		$this->plugin = $plugin;
		parent::__construct($plugin);
	}
  
	public function onRun($tick)
	{
		$allplayers = $this->plugin->getServer()->getOnlinePlayers();
		$level = $this->plugin->getServer()->getDefaultLevel();
		$tiles = $level->getTiles();
		foreach($tiles as $t) {
			if($t instanceof Sign) {	
				$text = $t->getText();
				if($text[3]==$this->prefix)
				{
					$aop = 0;
                                        $namemap = str_replace("§b", "", $text[2]);
					foreach($allplayers as $player){if($player->getLevel()->getFolderName()==$namemap){$aop=$aop+1;}}
					$ingame = TE::AQUA . "[Unirse]";
					$config = new Config($this->plugin->getDataFolder() . "/config.yml", Config::YAML);
					if($config->get($namemap . "PlayTime")!=700)
					{
						$ingame = TE::RED . "§c[Running]";
					}
					elseif($aop>=4)
					{
						$ingame = TE::GRAY . "§7[§bCombat§7]";
					}
                                        $t->setText($ingame,TE::WHITE  . $aop . " / §f4",$text[2],$this->prefix);
				}
			}
		}
	}
}

class GameSender extends PluginTask {
    public $prefix = "";
	public function __construct($plugin)
	{
		$this->plugin = $plugin;
                $this->prefix = $this->plugin->prefix;
		parent::__construct($plugin);
	}
        
        public function getResetmap() {
        Return new ResetMap($this);
        }
  
	public function onRun($tick)
	{
		$config = new Config($this->plugin->getDataFolder() . "/config.yml", Config::YAML);
		$arenas = $config->get("arenas");
		$slots = new Config($this->plugin->getDataFolder() . "/slots.yml", Config::YAML);
		if(!empty($arenas))
		{
			foreach($arenas as $arena)
			{
				$time = $config->get($arena . "PlayTime");
				$timeToStart = $config->get($arena . "StartTime");
				$levelArena = $this->plugin->getServer()->getLevelByName($arena);
				if($levelArena instanceof Level)
				{
					$playersArena = $levelArena->getPlayers();
					if(count($playersArena)==0)
					{
						$config->set($arena . "PlayTime", 700);
						$config->set($arena . "StartTime", 10);
                                                $config->set($arena . "inicio", 0);
					}
					else
					{
                                                if(count($playersArena)>=1)
                                                {
                                                    $config->set($arena . "inicio", 1);
                                                    $config->save();
                                                }
						if($config->get($arena . "inicio")==1)
						{
							if($timeToStart>0)
							{
								$timeToStart--;
								foreach($playersArena as $pl)
								{
									   //$t = str_repeat(" ", 85);
         //$pl->sendTip($t. "§r\n".$t. "§r\n".$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§l§6GameCube§r\n" .$t. "§r\n" .$t. "§a§lMap:§r§6 $arena §r\n" .$t. "§r\n" .$t. "§a§lEvent:§r\n" .$t. "§r\n" .$t. " §fWaiting§r\n" .$t. "§a§lTime:§r\n" .$t. "§r\n" .$t. "§6 $timeToStart §r\n" .$t. "§r\n" .$t. "§a§lPlayer: §f§r".  $player ."§r\n" .$t. "§r\n" .$t. "§a§lGame:§f§r MURDER§r\n" .$t. "§r\n" .$t."§l§6        MURDER MYSTERY§r".str_repeat("\n", 20));
									
                                                                        if($timeToStart<=5)
                                                                        {
                                                                        $levelArena->addSound(new PopSound($pl));
                                                                        }
                                                                        if($timeToStart<=0)
                                                                        {
                                                                        $levelArena->addSound(new AnvilUseSound($pl));
                                                                        }
								}
                                                                if($timeToStart==10)
                                                                {
                                                                    $levelArena->setTime(7000);
                                                                    $levelArena->stopTime();
                                                                }
                                                           
                                                
								    if($timeToStart == 10 || $timeToStart ==5 || $timeToStart ==4 || $timeToStart ==3 || $timeToStart ==2 || $timeToStart ==1)
									{
										foreach($playersArena as $pl)
										{
											
								$pl->addTitle(("§c $timeToStart "), ("§7| §6Preparate §7|"));
									
										}
									}
									
								if($timeToStart<=1)
								{
                                                                    foreach($playersArena as $pla)
                                                                    {
                                                                        if($slots->get("slot1".$arena)==$pla->getName())
                                                                        {
                                                                                $thespawn = $config->get($arena . "Spawn1");
                                                                        }
                                                                        elseif($slots->get("slot2".$arena)==$pla->getName())
                                                                        {
                                                                                $thespawn = $config->get($arena . "Spawn2");
                                                                        }
                                                                        elseif($slots->get("slot3".$arena)==$pla->getName())
                                                                        {
                                                                                $thespawn = $config->get($arena . "Spawn1");
                                                                        }
                                                                        elseif($slots->get("slot4".$arena)==$pla->getName())
                                                                        {
                                                                                $thespawn = $config->get($arena . "Spawn2");
                                                                        }
                                                                  
                                                                  
                                                                        $spawn = new Position($thespawn[0]+0.5,$thespawn[1],$thespawn[2]+0.5,$levelArena);
                                                                        $pla->teleport($spawn,0,0);
                                                                    }
                                                                    }
                                                               
								
								$config->set($arena . "StartTime", $timeToStart);
							}
							else
							{
                                                                $colors = array();
                                                                foreach($playersArena as $pl)
                                                                {
                                                                array_push($colors, $pl->getNameTag());
                                                                }
                                                                $names = implode("-", $colors);
                                                                $Red = substr_count($names, "§7[§4Rojo§7]§b");
                                                                $Blue = substr_count($names, "§7[§bAzul§7]§b");
                                                           
                                                                foreach($playersArena as $pla)
                                                                {
                                                                    if(strpos($pla->getNameTag(), "§7[§4Rojo§7]§b") !== false)
                                                                    {
                                                                   
                                                                    }
                                                                }
                                                                foreach($playersArena as $pla)
                                                                {
                                                                    
                                                                    
                                                                    if(strpos($pla->getNameTag(), "§7[§bAzul§7]§b") !== false)
                                                                    {
                                                                    
                                                                       $player = $pla->getPlayer()->getName();
                                                                    }
                                                                    
                                                                 
                                                                   if(strpos($pla->getNameTag(), "§7[§4Rojo§7]§b") !== false)
                                                                     {
                                                                            $player = $pla->getPlayer()->getName();
                                                                }
                                                               }
                                                                $winner = null;
                                                                $winners = array();
                                                                if($Red!=0 && $Blue==0)
                                                                {
                                                                   $winner = TE::RED."Equipo Rojo".TE::GRAY." Ganaron 2vs2 En§b ";
                                                                    foreach($playersArena as $pl)
                                                                    {
                                                                        if(strpos($pl->getNameTag(), "§7[§4Rojo§7]§b") !== false)
                                                                        {
                                                                            array_push($winners, $pl->getNameTag());
                                                                        }
                                                                    }
                                                                }
                                   
                                                               if($Red==0 && $Blue!=0)
                                                                {
                                                                    $winner = TE::AQUA."Equipo Azul".TE::GRAY." Ganaron 2vs2 En§b ";
                                                                    foreach($playersArena as $pl)
                                                                    {
                                                                        if(strpos($pl->getNameTag(), "§7[§bAzul§7]§b") !== false)
                                                                        {
                                                                            array_push($winners, $pl->getNameTag());
                                                                        }
                                                                    }
                                                                }
                                                                if($winner!=null)
                                                                {
                                                                    $this->plugin->getServer()->broadcastMessage($this->prefix .TE::GREEN. "§e>> ".$winner.TE::AQUA.$arena);
                                                                    $namewin = implode(", ", $winners);
                                                                    $this->plugin->getServer()->broadcastMessage($this->prefix .TE::GREEN. "§e>> ".TE::GRAY."§eGanador(es):".$namewin);
                                                                    foreach($playersArena as $pl)
                                                                    {
                                                                        $pl->getInventory()->clearAll();
                                                                        $pl->removeAllEffects();
                                                                        $pl->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn());
                                                                        $pl->setNameTag($pl->getName());
                                                      
                                                                        $config->set($arena . "PlayTime", 700);
                                                                        $config->set($arena . "StartTime", 10);
                                                                        $config->set($arena . "inicio", 0);
                                                                        $config->save();
                                                                    }
                                                                    $this->getResetmap()->reload($arena);
                                                                }
								$time--;
								if($time == 699)
								{
                                                                        $slots = new Config($this->plugin->getDataFolder() . "/slots.yml", Config::YAML);
                                                                        for ($i = 1; $i <= 4; $i++) {
                                                                        $slots->set("slot".$i.$arena, 0);
                                                                        }
                                                                        $slots->save();
                                                                        
									foreach($playersArena as $o)
									{
										
                                                                            $o->addTitle("§fPvP §6Start");
                                                                            $pl->sendMessage(TE::GOLD."-+-----------------------+-");
                                                                            $pl->sendMessage("§fWelcome to §b2vs2, §fThe Game Start");
                                                                            $pl->sendMessage("§fMap:§b $arena ");
                                                                            $pl->sendMessage("§fAttact your oponets, to win this game... §bYou have one team!");
                                                                            $pl->sendMessage(TE::GOLD."-+------------------------+-");
                                                                             $o->getInventory()->setContents(array(Item::get(0, 0, 0)));
               $o->getInventory()->clearAll();
                                                                            $a1 = Item::get(Item::DIAMOND_HELMET);
                                                                            $a2 = Item::get(Item::DIAMOND_CHESTPLATE);
                                                                            $a3 = Item::get(Item::DIAMOND_LEGGINGS);
                                                                            $a4 = Item::get(Item::DIAMOND_BOOTS);
                                                                            $i1 = Item::get(Item::BOW, 0, 1);
                                                                          
                                                                            $i3 = Item::get(ITEM::GOLDEN_APPLE, 0, 3);
                                                                          
                                                                            $i5 = Item::get(ITEM::ARROW, 0, 64);
                                                                            $enchant = Enchantment::getEnchantment(20);
                                                                            $enchant1 = Enchantment::getEnchantment(0);
                                                                            $enchant2 = Enchantment::getEnchantment(19);
                                                                            $enchant2->setLevel(2);
                                                                            $enchant->setLevel(3);
                                                                            $enchant1->setLevel(3);
                                                                            $a1->addEnchantment($enchant1);
                                                                            $a2->addEnchantment($enchant1);
                                                                            $a3->addEnchantment($enchant1);
                                                                                                                          $a4->addEnchantment($enchant1);
                                                                            $i1->addEnchantment($enchant);
                                                                            
                                                                            $o->getInventory()->setHelmet($a1);
							                                                $o->getInventory()->setChestplate($a2);
							                                                $o->getInventory()->setLeggings($a3);
							                                                $o->getInventory()->setBoots($a4);
							                                                $o->getInventory()->sendArmorContents($o);
							                                                $o->getInventory()->setItem(1, $i1);
							$o->getInventory()->setItem(15, Item::get(Item::ARROW, 0, 64));
							                                 $item = Item::get(Item::DIAMOND_SWORD, 0, 1);
                $item->addEnchantment(Enchantment::getEnchantment(10)->setLevel(3));
                                $item->addEnchantment(Enchantment::getEnchantment(11)->setLevel(3));
                                                $item->addEnchantment(Enchantment::getEnchantment(12)->setLevel(3));
                 $o->getInventory()->setItem(0, $item);
		                                                                    $o->getInventory()->addItem($i3);
                                                                           
									}
								}
								                                                
								
                                                                if($time <= 0)
                                                                {
                                                                    foreach($playersArena as $pl)
                                                                    {
                                                                            $pl->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn(),0,0);
                                                                            $pl->getInventory()->clearAll();
                                                                            $pl->removeAllEffects();
                                                                            $pl->setFood(20);
                                                                            $pl->setHealth(20);
                                                                            $pl->setNameTag($pl->getName());
                                                                            
                                                                            $config->set($arena . "inicio", 0);
                                                                            $config->save();
                                                                    }
                                                                
                                                                    $time = 700;
                                                                    $this->getResetmap()->reload($arena);
                                                                }
								$config->set($arena . "PlayTime", $time);
							}
						}
						else
						{
                                                    foreach($playersArena as $pl)
                                                    {
                                                    
                                                    	  $player = $pl->getPlayer()->getName();
                                                          //$t = str_repeat(" ", 85);
         //$pl->sendTip($t. "§r\n".$t. "§r\n".$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§r\n" .$t. "§l§6PegassoGamesPE§r\n" .$t. "§r\n" .$t. "§a§lMap:§r§6 $arena §r\n" .$t. "§r\n" .$t. "§a§lEvent:§r\n" .$t. "§r\n" .$t. " §fWaiting§r\n" .$t. "§a§lInGame:§r\n" .$t. "§r\n" .$t. "§6 $pl §r\n" .$t. "§r\n" .$t. "§a§lPlayer: §f§r". $player."§r\n" .$t. "§r\n" .$t. "§a§lGame:§f§r PvP§r\n" .$t. "§r\n" .$t."§l§6        2vs2§r".str_repeat("\n", 20));
			}
                                                    $config->set($arena . "PlayTime", 700);
                                                    $config->set($arena . "StartTime", 10);
						}
					}
				}
			}
		}
		$config->save();
	}
	
	}